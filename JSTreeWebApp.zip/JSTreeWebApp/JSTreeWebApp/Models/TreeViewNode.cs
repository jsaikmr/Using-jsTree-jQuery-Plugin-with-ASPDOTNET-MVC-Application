﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JSTreeWebApp.Models
{
    public class TreeViewNodeState
    {
        public bool selected { get; set; }
        public bool opened { get; set; }
        public bool checkbox_disabled { get; set; }
    }

    public class TreeViewNode
    {
        public string id { get; set; }
        public string parent { get; set; }
        public string text { get; set; }

        public TreeViewNodeState state { get; set; }
    }
}




