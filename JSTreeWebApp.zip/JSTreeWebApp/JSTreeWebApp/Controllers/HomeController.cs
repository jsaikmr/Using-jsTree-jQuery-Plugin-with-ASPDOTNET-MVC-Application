﻿using JSTreeWebApp.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace JSTreeWebApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            List<TreeViewNode> treeVNList = new List<TreeViewNode>()
            {
                new TreeViewNode()
                {
                    id = "1", text = "Parent_1 Node", parent = "#", 
                    state = new TreeViewNodeState() { selected = true, opened=true, checkbox_disabled=false}
                },
                new TreeViewNode()
                {
                    id = "1.1", text = "Child_1 Node of Parent_1", parent = "1", 
                    state = new TreeViewNodeState() { selected = true, opened=true, checkbox_disabled=false}
                },
                new TreeViewNode()
                {
                    id = "1.2", text = "Child_2 Node of Parent_1", parent = "1", 
                    state = new TreeViewNodeState() { selected = true, opened=true, checkbox_disabled=false}
                },
                new TreeViewNode()
                {
                    id = "2", text = "Parent_2 Node", parent = "#", 
                    state = new TreeViewNodeState() { selected = true, opened=true, checkbox_disabled=false}
                },
                new TreeViewNode()
                {
                    id = "2.1", text = "Child_1 Node of Parent_2", parent = "2", 
                    state = new TreeViewNodeState() { selected = true, opened=true, checkbox_disabled=false}
                }
            };

            ViewBag.JsonTreeData = (new JavaScriptSerializer()).Serialize(treeVNList);
            return View();
        }


        [HttpPost]
        public ActionResult Save(string selectedItems)
        {
            List<TreeViewNode> treeVNList = JsonConvert.DeserializeObject<List<TreeViewNode>>(selectedItems);

            return RedirectToAction("Index");
        }



        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}